#!/usr/bin/env bash

# a simple HELP  for ./$0 -h  option 
help_text="
Usage is a simple:
$0

This script will backup $TARGET_PATH
The result will be tarred, gzipped and encrypted with gpg.
It will be stored as:
$PATH_BU/backup_$TARGET_NAME.tar.gz.gpg

Uncomment this line at the bottom of the script if you want a date-stamped archive
#    cp "$GPG_FILE" backup_"$TARGET_NAME"_$(date +%Y%m%d).tar.gz.gpg

" 

while getopts h option
do
        case $option in
                h) echo "$help_text" ;
                   exit 0
        esac
done

# HEAD
#######
clear; date
echo

# VARIABLES
############
PATH_BU="/root/backup"
TARGET_PATH="/etc"
TARGET_NAME="etc"
GPG_FILE="$PATH_BU/backup_$TARGET_NAME.tar.gz.gpg"
TAR_FILE="$PATH_BU/backup_$TARGET_NAME.tar.gz"




# FUNCTIONS: check_root; ask_for; clean_up;check_exit
############
function check_root {
if [[ $(id -u) -ne 0 ]]
then
    echo "
    rerun as root"
    echo 
    exit 0
fi
}

function ask_for {
echo -n "
    Continue? (y/N): 
    "
read answer
case ${answer:0:1} in
	[Yy]) echo " Ok, we will move on" ;;
          *) echo "  Your answer has not been yes. Script will die. ";
	     clean_up ; 
	     exit ;; 
esac
}

function clean_up {
echo -n "
    Cleaning up...
    "
    rm -r "$PATH_BU"/"$TARGET_NAME"
    rm "$TAR_FILE"
}


function check_exit {
if  [[ $? -ne 0 ]]
then
    echo "
    An error occured"
    exit 0
fi 
}  


# TESTS
########
# Comment out check_root if you want to run the script as an unprivileged user.
check_root

# create PATH_BU if necessary
if ! [[ -d $PATH_BU ]] 
then
    mkdir "$PATH_BU" 
fi 
cd "$PATH_BU"


# Test for first run
#####################################################################
if ! [[ -f $GPG_FILE ]]
then
    echo "
    About to run:
    rsync -auv --delete-after $TARGET_PATH  $PATH_BU/$TARGET_NAME
    "
    ask_for
    rsync -auv --delete-after "$TARGET_PATH" .
    check_exit
    tar -czf "$TAR_FILE" "$TARGET_NAME"
    gpg -c "$TAR_FILE"
    clean_up
# Uncomment this next line if you want a date-stamped 
# duplicate file for permanent archive on the first run.
#    cp "$GPG_FILE" backup_"$TARGET_NAME"_$(date +%Y%m%d).tar.gz.gpg
    echo "
    This was the first run of your backup.
    We created a bacup_file called
    $GPG_FILE
    "
    echo
    exit 0
fi


# Repeat runs
########################################################################
# Decrypt and untar the backup file.

gpg --output "$TAR_FILE" --decrypt "$GPG_FILE"

echo "
    The backup file was decrypted.
    Please wait for it to be untarred.
    "
sleep 2

tar -xzf "$TAR_FILE"

# RSYNC
echo "
    About to run:
    rsync -auv --delete-after $TARGET_PATH  $PATH_BU/$TARGET_NAME
    "
    ask_for
rsync -auv --delete-after "$TARGET_PATH" .
check_exit

# Archive and encrypt the new backup, clean up.
echo "
    The new backup will be archived and encrypted.
    Give it a passphrase.
    "

rm "$TAR_FILE"
rm "$GPG_FILE"

tar -czf "$TAR_FILE" "$TARGET_NAME"
gpg -c "$TAR_FILE"
clean_up

# Uncomment this next line if you want a date-stamped 
# duplicate file for permanent archive on repeat runs.
#    cp "$GPG_FILE" backup_"$TARGET_NAME"_$(date +%Y%m%d).tar.gz.gpg

# FINISH
########
echo "Done!"

exit 0
