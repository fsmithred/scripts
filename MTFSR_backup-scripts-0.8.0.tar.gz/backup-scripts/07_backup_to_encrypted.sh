#!/usr/bin/env bash
# backup_to_encrypted.sh v. 0.2
# Back up to encrypted partition on another (probably external) drive (BU_DEV)
# Optionally create encrypted archive (tar.gz.gpg) 
# on another internal or external drive (ARCHIVE_DEV)



# NOTES:
#### This is currently set to back up /etc for testing purposes. ####
# To back up the system, edit the SRC variable from "/etc" to "/"
#  and the TAR_FILE variable to say "_OS_" instead of "_etc_" (or name it however you want).
# To use a different drive/partition (not my 120G WD Passport, second partition)
# change the uuid in the BU_DEV variable. (in Lenny, you can use disk labels, 
# but in Squeeze, blkid won't show the disk label on an encrypted partition.)

# VARIABLES - set these to suit your needs

# Directory to be backed up (Change to "/" for system backup.)
SRC="/etc"

# Destination directory for rsync.  Leave it as "" to back up to the root of the external drive.
# If SRC="/etc" and DEST="/backups", your files will end up in /backups/etc on the external drive.
DEST=""

# Path to the rsync excludes file
# Create one, or pick the appropriate one from the set. 
# Note: the $(pwd) assumes that the excludes file is in the same directory 
# as this script. Change to absolute path if needed.
EXCLUDES="/$(pwd)/test-excludes"

# The encrypted drive/partition which will hold the rsync'd backup:
# The long string of numbers is the UUID of the correct partition,
# and is the only part of this you should change.
BU_DEV="$(/sbin/blkid | awk -F ":" '/50123414-81f0-4e65-97d0-0019ceb2e210/ { print $1 }')"

# Label for the encrypted drive/partition to be used by cryptsetup and /dev/mapper
# and also used for the partition's mount point. Change it if you don't like the name. 
# If /mnt/$LABEL doesn't exist, it will be created.
LABEL="passport"

# Partition that holds the archive directory ($ARCHIVE_DIR)
# if you choose to make one. (The script will ask you.) 
# Don't use a full device name here. It also gets used 
# for the mount point. (example: use "sdb1" instead of "/dev/sdb1")
# If /mnt/$ARCHIVE_DEV doesn't exist, it will be created.
ARCHIVE_DEV="sdb1"

# Path to the directory to store the gpg-encrypted tar.gz file.
# Change the part after /mnt/$ARCHIVE_DEV/ for your archive folder.
ARCHIVE_DIR="/mnt/$ARCHIVE_DEV/files/backups/archives"

# Location/name of the archive file (change _etc_ to _OS_ or something else if appropriate)
TAR_FILE="$ARCHIVE_DIR/backup_$(hostname)_etc_$(date +%Y-%m-%d).tar.gz"




function check_root {
if [[ $(id -u) -ne 0 ]]
then
    echo "
    rerun as root"
    echo 
    exit 0
fi
}

function check_exit {
if  [[ $? -ne 0 ]]
then
    echo "
    An error occured"
    exit 1
fi 
}

function unmount_external {
	umount /mnt/$LABEL
    cryptsetup luksClose /dev/mapper/$LABEL
}

function unmount_archive_dev {
	umount /mnt/$ARCHIVE_DEV
}


clear; date
echo 
check_root


# create mountpoint for encrypted drive if necessary
if ! [[ -d /mnt/$LABEL ]] 
then
    mkdir /mnt/$LABEL 
fi 

# check if encrypted backup drive is mounted, or mount the drive by UUID.
if $(df | grep -q "/dev/mapper/$LABEL")
then
    echo "
        Backup drive is mounted.
        "
else
    cryptsetup luksOpen "$BU_DEV" "$LABEL"
    mount /dev/mapper/$LABEL /mnt/$LABEL
    check_exit
    echo "
        Backup drive is now mounted.
        "
fi

# Show what's in the root of the encrypted drive
# along with disk usage information.
# NOTE: I've seen the output of df change, so that it doesn't 
# display properly. You might need to change the fields that awk prints 
# to $3 and $4, or else use the line that says { print $0 } 

echo "Contents of backup drive:"
ls /mnt/"$LABEL"
#df -h | awk -v pattern=/mnt/$LABEL '$0 ~ pattern { print $0 }'
df -h | awk -v pattern=/mnt/$LABEL '$0 ~ pattern { print "    " $4 " " "Avail." "    " "("$5")" " " "Used" }'



echo -n "
    Would you like to run rsync now? (y/n)
    "
read answer
case ${answer:0:1} in
    [Yy]) echo "ok" ;;
    [Nn]) echo "
        Check the code.
        Unmount anything that needs to be unmounted.
        " 
                        exit 0 ;;
     * ) echo "
         Nothing has been done. Nothing has been unmounted.
         Have a break, pal
         " 
               exit 0
esac 


# run rsync and show disk information. (see note above)
rsync -auvx --exclude-from="$EXCLUDES"   $SRC /mnt/"$LABEL$DEST"
check_exit
echo "
    Rsync is finished.
    Contents of backup drive:
    "
    ls /mnt/"$LABEL"
#    df -h | awk -v pattern=/mnt/$LABEL '$0 ~ pattern { print $0 }'
    df -h | awk -v pattern=/mnt/$LABEL '$0 ~ pattern { print "    " $4 " " "Avail." "    " "("$5")" " " "Used" }'


# Ask if a tarred, encrypted, date-stamped archive is desired.

while true ; do
    echo -n "
    Would you like a date-stamped and 
    encrypted archive to be created at 
    $TAR_FILE.gpg?
    (y/n)
    "
read answer
    case "$answer" in
      [Nn]*) unmount_external ; check_exit ; echo "
        Exiting the script now...
        " ; exit 0 ;;
      [Yy]*) break ;;
    esac
done

# create mountpoint for archive drive if necessary
if ! [[ -d /mnt/$ARCHIVE_DEV ]] 
then
    mkdir /mnt/$ARCHIVE_DEV 
fi 


# check if drive to hold archive is mounted, or mount it.
if ! $(df | grep -q "/dev/$ARCHIVE_DEV")
then
    mount /dev/$ARCHIVE_DEV /mnt/$ARCHIVE_DEV
    check_exit
    echo "Archive drive is now mounted"
fi

echo -n "
Contents of archive directory:
"
ls -lh "$ARCHIVE_DIR"
df -h | awk -v pattern=$ARCHIVE_DEV '$0 ~ pattern { print "    " $4 " " "Avail." "    " "("$5")" " " "Used" }'


while true ; do
    echo -n "
    Make sure you have enough space to create the archive. 
    Continue?  (y/n)
    "
    read answer
    case "$answer" in
      [Nn]*) echo "
        Nothing will be unmounted.
        Exiting the script now...
        " ; exit 0 ;;
      [Yy]*) echo "
      You will be asked to create 
      a password for the archive.
                   
      Please wait." ; sleep 2 ; break ;;
    esac
done

tar -czf  $TAR_FILE  /mnt/"$LABEL$DEST$SRC" 
gpg -c $TAR_FILE 
rm $TAR_FILE 
echo "
     Encrypted archive was created.
           
         " 
    ls -lh "$ARCHIVE_DIR"    
    df -h | awk -v pattern=$ARCHIVE_DEV '$0 ~ pattern { print "    " $4 " " "Avail." "    " "("$5")" " " "Used" }'

echo "
     
    "
while true ; do
echo -n " Ready to exit. Please choose:
    "

echo "
    (a) unmount the external drive, but leave the archive drive mounted
    (b) unmount the archive drive, but leave the external drive mounted
    (c) unmount both the external and archive drives
    (d) leave both drives mounted
    "    
    read answer
    echo "
    Please wait...
    "
    case "$answer" in
        [Aa]*) unmount_external ; break ;;
        [Bb]*) unmount_archive_dev ;  break ;;
        [Cc]*) unmount_external ; unmount_archive_dev ; break ;;
        [Dd]*) break ;;
    esac
done

echo "
Bye!
"

exit 0


