#!/usr/bin/env bash


# HELP ./$0 -h  option 
###############
help_text="
Usage is a simple:
./$0

This script will rsync all the elements of SOURCE_PATH -list 
with Dropbox.
If you want different sources or a different target edit:
SOURCE_PATH and TARGET_PATH 
" 

while getopts h option
do
        case $option in
                h) echo "$help_text" ;
                   exit 0
        esac
done

#HEAD 
clear; date
echo

#VARIABLES
##########
echo -n "
    Tell us first for which users data you want to rsync with Dropbox: "    
read BU_USER

# you can take any folder instead of Dropbox, as long you got read/write and don't need to mount it
TARGET_PATH="/home/$BU_USER/Dropbox"
SOURCE_PATH=(
/root/backup
/root/Configs
/home/$BU_USER/Documents
/home/$BU_USER/Pictures/{avatar,gimp_art,napooh,screenshot,this_that,wallpapers}
/home/$BU_USER/Programming
/home/$BU_USER/bin
)

echo " 
    All the folders of SOURCE_PATH will be backup up in Dropbox
    In case you want to change it add/remove to the rsync commans at the bottom.
    Edit SOURCE_PATH to get the correct info.
    :-\) "
echo
sleep 3 

for e in ${SOURCE_PATH[@]}
do
	echo "$e"
done
echo 

#FUNCTIONS
##########
# comment in case you got read/write for all SOURCE_PATH-folders. 
function check_root {
if [[ $(id -u) -ne 0 ]]
then
    echo "
    rerun as root"
    echo 
    exit 0
fi
}


function ask_for {
echo -n "
    You want to go on? (answer yes or no): "
read answer
case ${answer:0:1} in
	[Yy]) echo " Ok, we will move on" ;;
          *) echo "  Your answer has not been yes. Script will die. ";
	     exit ;; 
esac
}



function check_exit {
if [[ $? -ne 0 ]]
then
	echo "
	An error occured"
        exit 1
fi
}


#TESTS 
#######

# comment, if you dont want to or need to  run it as root
check_root

# check for the  $TARGET_PATH being existent
if ! [[ -d $TARGET_PATH ]]
then 
	mkdir $TARGET_PATH
fi

# check for source directory, if the user is existent
if ! [[ -d /home/$BU_USER ]]
then
    echo "
        $BU_USER does not exist.
        Use a valid user name.
        "
    exit 0
fi 


# RSYNC it
ask_for

rsync -auv --delete /root/backup "$TARGET_PATH"
rsync -auv --delete /root/Configs "$TARGET_PATH"
rsync -auv --delete /home/$BU_USER/Documents "$TARGET_PATH"
rsync -auv --delete /home/$BU_USER/Pictures/{avatar,gimp_art,napooh,screenshot,this_that,wallpapers} "$TARGET_PATH"/Pictures
rsync -auv --delete /home/$BU_USER/Programming "$TARGET_PATH"
rsync -auv --delete /home/$BU_USER/bin "$TARGET_PATH"

#uncomment later (?)
chown -R $BU_USER:  $TARGET_PATH 

echo "
    Done"

exit 0

