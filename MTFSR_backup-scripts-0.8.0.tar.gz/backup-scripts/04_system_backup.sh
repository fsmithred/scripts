#!/usr/bin/env bash

# device for me, m.tornow,  is probably /dev/sde1

# the help text will be shown in case the user uses the -h option
help_text="
Usage:
$0  /dev/sdxY  

(Where /dev/sdxY is replaced with the partition on
the external drive where the backup copy will reside.)

See 4_system_excludes for the list of exclusions.
" 

while getopts h option
do
case $option in
                h) echo "$help_text" ;
                   exit 0
        esac
done

# HEAD
clear; date
echo 

# VARIABLES
BU_MP="/media/backup"
BU_DEV=$1
EXCLUDES="$(pwd)/4_system_excludes"


# FUNCTIONS: check_root; check_exit; ask_for
function check_root {
if [[ $(id -u) -ne 0 ]]
then
    echo "
    rerun as root"
    echo 
    exit 0
fi
}


function check_exit {
if  [[ $? -ne 0 ]]
then
    echo "
    An error occured"
    echo
    exit 0
fi 
}  


function ask_for {
echo -n "
    Continue? (y/N): 
    "
read answer
case ${answer:0:1} in
	[Yy]) echo " Ok, we will move on" ;;
          *) echo "  Your answer has not been yes. Script will die. ";
             if $(df | grep -q $BU_DEV)
             then
                  umount "$BU_DEV"
             fi ; 
	     exit 1  ;; 
esac
}


# TESTS
######## 

check_root

#check if the parameter for mounting the  device is added
if ! [[ $# -eq 1 ]]
then
    echo "
    You missed to add the (backup-)device which is  to be mounted. Do it now:
    Here is the actual output of \"fdisk -l \" " 
    sleep 3 
    fdisk -l
    echo -n "which one, full name, like /dev/sdx? "
    read BU_DEV
fi

#  check if it is a valid device:
if ! [[ -b $BU_DEV ]]
then
    echo "
    You did not add a valid device. Start over"
    exit 0
fi 

# create BU_MP if necessary

if ! [[ -d $BU_MP ]] 
then
    mkdir "$BU_MP" 
fi 
 
# make sure the backup device isn't  already mounted, then mount it.

if $(df | grep -q $BU_DEV)
then
    umount "$BU_DEV"
fi

echo "
    We will mount $BU_DEV on $BU_MP "
   
ask_for 


mount "$BU_DEV" "$BU_MP"

echo "
    Contents of "$BU_MP" 
    "
ls "$BU_MP"

echo -n "
    We will run rsync now? 
    "
ask_for



# RSYNC
######## 

rsync -auvx --exclude-from="$EXCLUDES"  --delete-after / "$BU_MP"
check_exit

# FINISH 
echo "
    Rsync did finish, here is the actual content of $BU_MP"
echo 
ls "$BU_MP"

echo "
    If it is wrong you are on your own. 
    Please wait while "$BU_MP" is unmounted."
    
umount "$BU_MP"

if [[ $(which notify-send) ]]
then
   notify-send "Backup is done"
else
   echo "
   If you want to be informed by a pop-up
   that the backup is finished do:
   apt-get install libnotify-bin
   Handy for long backups. More prunes :-)"
fi
echo " Done" 

exit 0

