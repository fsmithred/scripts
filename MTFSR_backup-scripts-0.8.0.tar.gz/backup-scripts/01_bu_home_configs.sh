#!/bin/bash

# the help text will be shown in case the user uses the -h option
help_text="
Usage is a simple:
$0  <username>

This script will backup the hidden directories in your home.
The result will be tarred, gzipped and encrypted with gpg.
It will be stored as:
$PATH_BU/backup_$TARGET_NAME.tar.gz.gpg

See 1_userconfig_excludes for the list of exclusions.
Make sure the path of the EXCLUDES variable is correct 
" 

while getopts h option
do
case $option in
                h) echo "$help_text" ;
                   exit 0
esac
done 

# head
clear; date
echo 

# Variables
PATH_BU="/root/backup"
TARGET_PATH="/home/$1"
TARGET_NAME="$1_configs"
GPG_FILE="$PATH_BU/backup_$TARGET_NAME.tar.gz.gpg"
TAR_FILE="$PATH_BU/backup_$TARGET_NAME.tar.gz"
EXCLUDES="$(pwd)/1_userconfig_excludes"
# NOTE: perhaps add a if [[ -f $EXCLUDES ]] ?; to be sure the file has got downloaded?

# Functions: check_root; ask_for; clean_up;check_exit
function check_root {
if [[ $(id -u) -ne 0 ]]
then
    echo "
    rerun as root"
    echo 
    exit 0
fi
}

function ask_for {
echo -n "
    Continue? (y/N): 
    "
read answer
case ${answer:0:1} in
	[Yy]) echo " Ok, we will move on" ;;
          *) echo "  Your answer has not been yes. Script will die. ";
	     clean_up ; 
	     exit ;; 
esac
}

function clean_up {
echo -n "
    Cleaning up...
    "
    rm -r "$PATH_BU"/"$TARGET_NAME"
    rm "$TAR_FILE"
}


function check_exit {
if  [[ $? -ne 0 ]]
then
    echo "
    An error occured"
    exit 0
fi 
}  


function alert {
if [[ $(which notify-send) ]]
then
   notify-send "Backup script needs input."
else
   echo "
   If you want to be informed by a pop-up
   that the backup is finished do:
   apt-get install libnotify-bin
   Handy for long backups. More prunes :-)"
fi	
}

# tests 

# check for the first argument, the users name
if [[ "$#" -ne 1 ]]
then
    echo "
    ERROR
    You didn't add a user name as a parameter:"
    echo  
    echo "$help_text"
    exit 0
fi 


# Comment out check_root if you want to run the script as an unprivileged user.
check_root

# create PATH_BU if necessary
if ! [[ -d $PATH_BU ]] 
then
    mkdir "$PATH_BU" 
fi 
cd "$PATH_BU"


# Test for first run

if ! [[ -f $GPG_FILE ]]
then
    echo "
    About to run:
    rsync -auvx --delete-after --exclude-from="$EXCLUDES" $TARGET_PATH/.[a-z,A-Z,0-9]* $PATH_BU/$TARGET_NAME
    "
    ask_for
    rsync -auvx --delete-after --exclude-from="$EXCLUDES"  $TARGET_PATH/.[a-z,A-Z,0-9]* $PATH_BU/$TARGET_NAME
    check_exit 
    tar -czf "$TAR_FILE" "$TARGET_NAME"
    gpg -c "$TAR_FILE"
    clean_up
# Uncomment this next line if you want a date-stamped 
# duplicate file for permanent archive on the first run.
#    cp "$GPG_FILE" backup_"$TARGET_NAME"_$(date +%Y%m%d).tar.gz.gpg
    echo "
    This was the first run of your backup.
    We created a backup_file called
    $GPG_FILE
    "
    echo
    exit 0
fi


# Repeat runs

# Decrypt and untar the backup file.

gpg --output "$TAR_FILE" --decrypt "$GPG_FILE"

echo "
    The backup file was decrypted.
    Please wait for it to be untarred.
    "
sleep 2

tar -xzf "$TAR_FILE"


# RSYNC
echo "
    About to run:
    rsync -auvx --delete-after --exclude-from="$EXCLUDES" $TARGET_PATH/.[a-z,A-Z,0-9]* $PATH_BU/$TARGET_NAME
    "
    alert
    ask_for
    rsync -auvx --delete-after --exclude-from="$EXCLUDES" $TARGET_PATH/.[a-z,A-Z,0-9]* $PATH_BU/$TARGET_NAME
    check_exit
    
# Archive and encrypt the new backup, clean up.
echo "
    The new backup will be archived and encrypted.
    Give it a passphrase.
    "

rm "$TAR_FILE"
rm "$GPG_FILE"

tar -czf "$TAR_FILE" "$TARGET_NAME"
alert
gpg -c "$TAR_FILE"
clean_up


# Uncomment this next line if you want a date-stamped 
# duplicate file for permanent archive on repeat runs.
#    cp "$GPG_FILE" backup_"$TARGET_NAME"_$(date +%Y%m%d).tar.gz.gpg


if [[ $(which notify-send) ]]
then
   notify-send "Backup is done"
else
   echo "
   If you want to be informed by a pop-up
   that the backup is finished do:
   apt-get install libnotify-bin
   Handy for long backups. More prunes :-)"
fi
echo "Done!"

exit 0
