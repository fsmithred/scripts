#!/usr/bin/env bash


# HELP
#######
help_text="
Usage:
$0  <device_of_backup> <device_of_archive>

This script will make an tar/gzip archive of your system backup.
If unsure run \"fdisk -l\"  
"

function show_help {
	echo "$help_text"
    exit 0
}

# Manual loop to handle any arbitrary set of options.
while [[ $1 == -* ]]; do
    case "$1" in
      -h|--help|-\?) show_help; exit 0;;
      -*) echo "
    invalid option: $1
    
    valid options: -h, --help, -?,        show this help message
              " 
              1>&2; show_help; exit 1;;
    esac
done

#  HEAD 
###########
clear; date
echo 

# VARIABLES 
###########

SOURCE_DEV=$1
TARGET_DEV=$2
SOURCE_MP="/media/restore"
TARGET_MP="/media/backup"
ARCHIVE="$TARGET_MP"/Backup

# the FUNCTIONS: 
# check_root, check_exit;ask_for
####################

function check_root {
if [[ $(id -u) -ne 0 ]]
then
    echo "
    rerun as root"
    echo 
    exit 0
fi
}

function check_exit {
if  [[ $? -ne 0 ]]
then
    echo "
    An error occured"
    exit 1
fi 
}

function ask_for {
echo -n "
    You want to go on? (answer yes or no): "
read answer
case ${answer:0:1} in
	[Yy]) echo " Ok, we will move on" ;;
          *) echo "  Your answer has not been yes. Script will die. ";
             if $(df | grep -q $BU_DEV)
             then
                  umount "$BU_DEV"
             fi ;
	     exit ;; 
esac
}

#####################################################
# TESTS for the things we need:
# a) user needs to be root
# b) he need to have added two devices to mount
# c) both need to be block devices, or valid devices
# d) tell what we do and ask_for 
# e) mount source and target, list content and ask_for
# f) make sure ARCHIVE does exist
######################################################

# check for root
check_root

# check for devices:
if [[ $# -ne 2 ]]
then 
	echo "ERROR"
        show_help
fi 

# check  both devices 
if ! [[ -b $1 &&  -b $2 ]]
then
	echo "ERROR: one of the devices is not a valid block device"
	echo
	show_help
fi 

# check if they are already mounted:
#source-dev
if $(df | grep -q $SOURCE_DEV)
then
    umount "$SOURCE_DEV"
fi
#target-dev
if $(df | grep -q $TARGET_DEV)
then
    umount "$TARGET_DEV"
fi


# tell what mount where and ask_for
echo "
    We will mount:
    $SOURCE_DEV at $SOURCE_MP
    and
    $TARGET_DEV at $TARGET_MP"
ask_for


# mount it; check exits
mount $SOURCE_DEV $SOURCE_MP
check_exit
mount $TARGET_DEV $TARGET_MP
check_exit

# list the content and ask for:
echo "
    The actual content of the source  $SOURCE_MP"
echo
ls $SOURCE_MP
ask_for

if ! [[ -d $ARCHIVE ]]
then 
    mkdir $ARCHIVE
    check_exit
fi  

echo "
    The actual content of the target $TARGET_MP"
echo 
ls $TARGET_MP
ask_for


# TAR it
#########
tar -czf "$TARGET_MP"/Backup/backup_$(hostname)_$(date +%m-%d).tar.gz "$SOURCE_MP"


# FINISH info and umounting
##########
# notify-send, comment if you ain't got it
notify-send "taring the backup: finished"

echo "
     Here is the actual content of $ARCHIVE
     It should contain a file with the date of today: $(date +%m-%d) 
     If things are wrong you are on your own"
echo

ls "$ARCHIVE"
echo "
     If it is not ok, there is not much you can do"

# umount the devices
umount "$SOURCE_MP" "$TARGET_MP"
check_exit

echo "Done"

exit 0
